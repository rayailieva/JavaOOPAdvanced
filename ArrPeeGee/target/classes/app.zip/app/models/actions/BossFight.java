package app.models.actions;

import app.contracts.Action;
import app.contracts.Targetable;

import java.util.List;

public class BossFight implements Action {

    @Override
    public String executeAction(List<Targetable> participants) {
        return null;
    }
}
